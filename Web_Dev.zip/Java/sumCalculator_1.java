public class sumCalculator{

	private double firstNumber;
	private double secondNumber;
	
	public double getFirstNumber()
	{
		return this.firstNumber;
	}
	
	public double getSecondNumber()
	{
			return this.secondNumber;
	}
	
	public void setFirstNumber(double number)
	{
		this.firstNumber = number;
	}
	
	public void setSecondNumbe(double number)
	{
		
		this.secondNumber = number;
	}
	
	public void getAdditionResult()
	{
		
		return (double) (this.firstNumber + this.secondNumber);
	}
	
	public void getSubtractionResult()
	{
		return (double) (this.firstNumber - this.secondNumber);
		
	}
	
	public void getMultiplicationResult()
	{
		
		return (double) (this.firstNumber * this.secondNumber);
		
	}
	
	public void getDivisionResult()
	{
		
			if(this.secondNumber==0)
			{
				return 0.0;
			}
			else
			{
				return (double) (this.firstNumber / this.secondNumber);
			}
	}
	
	
	
	
	
	
	